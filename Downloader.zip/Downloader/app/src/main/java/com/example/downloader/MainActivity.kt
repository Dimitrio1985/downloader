package com.example.downloader

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Environment
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*

val Bg = Color(0xFF0A0D14)
val Card = Color(0xFF131826)
val Blue = Color(0xFF3B82F6)
val Dim = Color(0xFF8A93A6)

enum class St { RUN, PAUSED, DONE, ERR }

class Dl(val id: Int, val url: String, val name: String) {
    var total by mutableLongStateOf(-1L)
    var done by mutableLongStateOf(0L)
    var speed by mutableLongStateOf(0L)
    var status by mutableStateOf(St.RUN)
    val date: String = SimpleDateFormat("dd.MM.yyyy, HH:mm", Locale.getDefault()).format(Date())
    var job: Job? = null
    val progress: Float get() = if (total > 0) (done.toFloat() / total).coerceIn(0f, 1f) else 0f
}

object Store {
    val items = mutableStateListOf<Dl>()
    private var next = 1
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    fun dir(c: Context): File = c.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)!!

    fun add(c: Context, url: String): Dl {
        val n = url.substringBefore('?').substringAfterLast('/').ifBlank { "file" }
        val d = Dl(next++, url, n)
        items.add(0, d)
        begin(c, d)
        return d
    }

    fun begin(c: Context, d: Dl) {
        d.status = St.RUN
        d.job = scope.launch {
            try {
                val conn = URL(d.url).openConnection() as HttpURLConnection
                conn.connectTimeout = 15000
                conn.readTimeout = 15000
                if (d.done > 0) conn.setRequestProperty("Range", "bytes=${d.done}-")
                conn.connect()
                val code = conn.responseCode
                if (code >= 400) throw java.io.IOException("HTTP $code")
                val append = code == 206
                if (!append) d.done = 0
                val len = conn.contentLengthLong
                d.total = if (len > 0) len + d.done else -1
                conn.inputStream.use { inp ->
                    FileOutputStream(File(dir(c), d.name), append).use { out ->
                        val buf = ByteArray(32768)
                        var last = System.nanoTime()
                        var lastB = d.done
                        while (true) {
                            ensureActive()
                            val n = inp.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            d.done += n
                            val now = System.nanoTime()
                            if (now - last > 1_000_000_000L) {
                                d.speed = ((d.done - lastB) * 1_000_000_000L / (now - last))
                                last = now
                                lastB = d.done
                            }
                        }
                    }
                }
                d.speed = 0
                if (d.total < 0) d.total = d.done
                d.status = St.DONE
            } catch (e: CancellationException) {
            } catch (e: Exception) {
                d.speed = 0
                d.status = St.ERR
            }
        }
    }

    fun pause(d: Dl) {
        d.job?.cancel()
        d.speed = 0
        d.status = St.PAUSED
    }

    fun delete(c: Context, d: Dl) {
        d.job?.cancel()
        File(dir(c), d.name).delete()
        items.remove(d)
    }
}

fun fsz(b: Long): String = when {
    b < 0 -> "—"
    b >= 1L shl 30 -> "%.1f ГБ".format(b / 1073741824.0)
    b >= 1L shl 20 -> "%.1f МБ".format(b / 1048576.0)
    else -> "${b / 1024} КБ"
}

fun ext(n: String) = n.substringAfterLast('.', "").lowercase()
fun kindColor(n: String) = when (ext(n)) {
    "mp4", "mkv", "avi", "webm", "mov" -> Color(0xFF6D5BF0)
    "mp3", "wav", "flac", "m4a", "ogg" -> Color(0xFFF0506E)
    "zip", "rar", "7z", "tar", "gz" -> Color(0xFFF5A623)
    "pdf", "txt", "doc", "docx" -> Color(0xFF22B07D)
    else -> Blue
}
fun kindName(n: String) = when (ext(n)) {
    "mp4", "mkv", "avi", "webm", "mov" -> "Видео (${ext(n).uppercase()})"
    "mp3", "wav", "flac", "m4a", "ogg" -> "Аудио (${ext(n).uppercase()})"
    "zip", "rar", "7z", "tar", "gz" -> "Архив (${ext(n).uppercase()})"
    "pdf", "txt", "doc", "docx" -> "Документ (${ext(n).uppercase()})"
    else -> "Файл"
}
fun kindIcon(n: String): ImageVector = when (ext(n)) {
    "mp4", "mkv", "avi", "webm", "mov" -> Icons.Default.PlayArrow
    "mp3", "wav", "flac", "m4a", "ogg" -> Icons.Default.MusicNote
    "zip", "rar", "7z", "tar", "gz" -> Icons.Default.FolderZip
    else -> Icons.Default.Description
}
fun stText(d: Dl) = when (d.status) {
    St.RUN -> "Загружается"; St.PAUSED -> "Пауза"; St.DONE -> "Завершено"; St.ERR -> "Ошибка"
}

fun fileUri(c: Context, d: Dl) =
    FileProvider.getUriForFile(c, c.packageName + ".fileprovider", File(Store.dir(c), d.name))

fun openFile(c: Context, d: Dl) = try {
    val u = fileUri(c, d)
    c.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, c.contentResolver.getType(u) ?: "*/*")
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
} catch (e: Exception) {}

fun shareFile(c: Context, d: Dl) = try {
    val i = Intent(Intent.ACTION_SEND).setType("*/*").putExtra(Intent.EXTRA_STREAM, fileUri(c, d))
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    c.startActivity(Intent.createChooser(i, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
} catch (e: Exception) {}

sealed class Scr {
    object Home : Scr(); object Lst : Scr(); object Add : Scr(); object Set : Scr()
    class Prog(val d: Dl) : Scr()
    class Info(val d: Dl) : Scr()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Blue, background = Bg, surface = Card,
                onBackground = Color.White, onSurface = Color.White)) {
                Surface(Modifier.fillMaxSize(), color = Bg) { App() }
            }
        }
    }
}

@Composable
fun App() {
    val c = LocalContext.current
    val st = remember { mutableStateListOf<Scr>(Scr.Home) }
    val back: () -> Unit = { if (st.size > 1) st.removeAt(st.lastIndex) }
    BackHandler(st.size > 1) { back() }
    fun go(s: Scr) { st.add(s) }
    fun start(u: String) { go(Scr.Prog(Store.add(c, u))) }
    when (val s = st.last()) {
        Scr.Home -> Home({ start(it) }, { go(Scr.Lst) })
        Scr.Lst -> ListScr({ go(Scr.Set) }, { go(if (it.status == St.DONE) Scr.Info(it) else Scr.Prog(it)) }, { go(Scr.Add) }, back)
        Scr.Add -> AddScr(back) { start(it) }
        Scr.Set -> SetScr(back)
        is Scr.Prog -> ProgScr(s.d, back) { go(Scr.Info(s.d)) }
        is Scr.Info -> InfoScr(s.d, back) {
            while (st.size > 1 && st.last() !is Scr.Lst) st.removeAt(st.lastIndex)
        }
    }
}

@Composable
fun Bar(title: String, back: (() -> Unit)?, actions: @Composable RowScope.() -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp).height(48.dp),
        verticalAlignment = Alignment.CenterVertically) {
        if (back != null) IconButton(onClick = back) { Icon(Icons.Default.ArrowBack, null) } else Spacer(Modifier.width(12.dp))
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
        actions()
    }
}

@Composable
fun FileIcon(n: String, s: Int = 48) =
    Box(Modifier.size(s.dp).clip(RoundedCornerShape((s / 4).dp)).background(kindColor(n)), contentAlignment = Alignment.Center) {
        Icon(kindIcon(n), null, Modifier.size((s / 2).dp), tint = Color.White)
    }

@Composable
fun Home(onGo: (String) -> Unit, onList: () -> Unit) {
    var url by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(120.dp).border(4.dp, Blue, CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Download, null, Modifier.size(56.dp))
        }
        Spacer(Modifier.height(24.dp))
        Text("Загрузчик файлов", fontSize = 30.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text("Скачивайте файлы быстро и удобно", color = Dim, textAlign = TextAlign.Center)
        Spacer(Modifier.height(40.dp))
        OutlinedTextField(url, { url = it }, Modifier.fillMaxWidth(), singleLine = true,
            placeholder = { Text("Вставьте ссылку на файл") },
            leadingIcon = { Icon(Icons.Default.Link, null) }, shape = RoundedCornerShape(16.dp))
        Spacer(Modifier.height(12.dp))
        Button({ if (url.isNotBlank()) onGo(url.trim()) }, Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(27.dp)) { Text("Скачать") }
        TextButton(onList) { Text("Мои загрузки") }
    }
}

@Composable
fun ListScr(onSet: () -> Unit, onOpen: (Dl) -> Unit, onAdd: () -> Unit, back: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    val c = LocalContext.current
    Box(Modifier.fillMaxSize()) {
        Column {
            Bar("Загрузки", back) { IconButton(onClick = onSet) { Icon(Icons.Default.Settings, null) } }
            TabRow(selectedTabIndex = tab, containerColor = Bg) {
                listOf("Все", "Завершённые", "В процессе").forEachIndexed { i, t ->
                    Tab(tab == i, { tab = i }, text = { Text(t, fontSize = 13.sp, maxLines = 1) })
                }
            }
            val shown = Store.items.filter { when (tab) { 1 -> it.status == St.DONE; 2 -> it.status != St.DONE; else -> true } }
            if (shown.isEmpty()) Box(Modifier.fillMaxSize(), Alignment.Center) { Text("Пока пусто", color = Dim) }
            LazyColumn {
                items(shown, key = { it.id }) { d ->
                    Row(Modifier.fillMaxWidth().clickable { onOpen(d) }.padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        FileIcon(d.name)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(d.name, maxLines = 1)
                            Text("${fsz(maxOf(d.total, d.done))} • ${stText(d)}", color = Dim, fontSize = 12.sp)
                            if (d.status == St.DONE) Text(d.date, color = Dim, fontSize = 12.sp)
                            else LinearProgressIndicator(progress = { d.progress }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp), color = Blue)
                        }
                        var m by remember { mutableStateOf(false) }
                        Box {
                            IconButton(onClick = { m = true }) { Icon(Icons.Default.MoreVert, null, tint = Dim) }
                            DropdownMenu(m, { m = false }) {
                                DropdownMenuItem(text = { Text("Удалить") }, onClick = { m = false; Store.delete(c, d) })
                            }
                        }
                    }
                }
            }
        }
        FloatingActionButton(onClick = onAdd, modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp),
            containerColor = Blue, shape = CircleShape) { Icon(Icons.Default.Add, null, tint = Color.White) }
    }
}

@Composable
fun Opt(icon: ImageVector, t: String, sub: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Dim)
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) { Text(t); Text(sub, color = Dim, fontSize = 12.sp, maxLines = 1) }
        Icon(Icons.Default.ChevronRight, null, tint = Dim)
    }
}

@Composable
fun AddScr(back: () -> Unit, go: (String) -> Unit) {
    var u by remember { mutableStateOf("") }
    val n = u.substringBefore('?').substringAfterLast('/').ifBlank { "file" }
    Column(Modifier.fillMaxSize()) {
        Bar("Добавить ссылку", back)
        Column(Modifier.weight(1f).padding(16.dp)) {
            OutlinedTextField(u, { u = it }, Modifier.fillMaxWidth(), singleLine = true,
                placeholder = { Text("https://example.com/file.zip") },
                leadingIcon = { Icon(Icons.Default.Link, null) },
                trailingIcon = { if (u.isNotEmpty()) IconButton(onClick = { u = "" }) { Icon(Icons.Default.Close, null) } },
                shape = RoundedCornerShape(12.dp))
            Spacer(Modifier.height(20.dp))
            Text("Параметры загрузки", color = Dim)
            Opt(Icons.Default.Folder, "Сохранить в", "Загрузки")
            Opt(Icons.Default.Description, "Имя файла", n)
            Opt(Icons.Default.Inventory2, "Категория", kindName(n).substringBefore(" ("))
        }
        Button({ if (u.isNotBlank()) go(u.trim()) }, Modifier.fillMaxWidth().padding(16.dp).height(52.dp),
            shape = RoundedCornerShape(26.dp)) { Text("Скачать") }
    }
}

@Composable
fun Stat(label: String, value: String) =
    Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(value); Text(label, color = Dim, fontSize = 12.sp) }

@Composable
fun ProgScr(d: Dl, back: () -> Unit, info: () -> Unit) {
    val c = LocalContext.current
    Column(Modifier.fillMaxSize()) {
        Bar("Загрузка", back)
        Column(Modifier.weight(1f).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(40.dp))
            FileIcon(d.name, 72)
            Spacer(Modifier.height(12.dp))
            Text(d.name, fontSize = 18.sp)
            val eta = if (d.status == St.RUN && d.speed > 0 && d.total > 0) "${(d.total - d.done) / d.speed / 60 + 1} мин осталось" else stText(d)
            Text("${fsz(d.total)} • $eta", color = Dim, fontSize = 13.sp)
            Spacer(Modifier.height(32.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                LinearProgressIndicator(progress = { d.progress }, modifier = Modifier.weight(1f), color = Blue)
                Text("${(d.progress * 100).toInt()}%", Modifier.padding(start = 12.dp))
            }
            Spacer(Modifier.height(32.dp))
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly) {
                Stat("Скорость", "${fsz(d.speed)}/с")
                Stat("Загружено", fsz(d.done))
            }
        }
        OutlinedButton(onClick = { when (d.status) { St.RUN -> Store.pause(d); St.DONE -> info(); else -> Store.begin(c, d) } },
            modifier = Modifier.fillMaxWidth().padding(24.dp).height(50.dp), shape = RoundedCornerShape(25.dp)) {
            Text(when (d.status) { St.RUN -> "Пауза"; St.DONE -> "Подробнее"; St.PAUSED -> "Продолжить"; St.ERR -> "Повторить" })
        }
    }
}

@Composable
fun KV(k: String, v: String) =
    Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 12.dp)) {
        Text(k, Modifier.weight(1f)); Text(v, color = Dim)
    }

@Composable
fun Act(icon: ImageVector, t: String, onClick: () -> Unit) =
    Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 24.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically) { Icon(icon, null); Spacer(Modifier.width(16.dp)); Text(t) }

@Composable
fun InfoScr(d: Dl, back: () -> Unit, deleted: () -> Unit) {
    val c = LocalContext.current
    Column(Modifier.fillMaxSize()) {
        Bar("О файле", back)
        Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            FileIcon(d.name, 72)
            Spacer(Modifier.height(12.dp))
            Text(d.name, fontSize = 18.sp)
            Text(fsz(d.total), color = Dim, fontSize = 13.sp)
        }
        KV("Тип", kindName(d.name)); KV("Размер", fsz(d.total)); KV("Расположение", "Загрузки"); KV("Дата загрузки", d.date)
        Spacer(Modifier.height(24.dp))
        Act(Icons.Default.PlayArrow, "Открыть") { openFile(c, d) }
        Act(Icons.Default.Share, "Поделиться") { shareFile(c, d) }
        Act(Icons.Default.Delete, "Удалить") { Store.delete(c, d); deleted() }
    }
}

@Composable
fun SetScr(back: () -> Unit) {
    val c = LocalContext.current
    var on by remember { mutableStateOf(true) }
    Column(Modifier.fillMaxSize()) {
        Bar("Настройки", back)
        Column(Modifier.padding(horizontal = 16.dp)) {
            Opt(Icons.Default.Folder, "Папка загрузок", Store.dir(c).path)
            Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Notifications, null, tint = Dim)
                Spacer(Modifier.width(16.dp))
                Text("Уведомления", Modifier.weight(1f))
                Switch(on, { on = it })
            }
            Opt(Icons.Default.DarkMode, "Тема", "Тёмная")
            HorizontalDivider(Modifier.padding(vertical = 8.dp), color = Card)
            Opt(Icons.Default.Info, "О приложении", "Загрузчик файлов 1.0")
        }
    }
}
